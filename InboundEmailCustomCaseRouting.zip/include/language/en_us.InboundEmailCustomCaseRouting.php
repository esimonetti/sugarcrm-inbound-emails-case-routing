<?php 
$app_list_strings['case_status_dom']['Email Received'] = 'Email Received';
